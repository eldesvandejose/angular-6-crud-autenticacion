/* SystemJS module definition */
declare var jQuery: any;
declare var $: any;
