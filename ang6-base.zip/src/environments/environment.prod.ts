export const environment = {
  production: true,
  APIS_URL: 'http://localhost/a6b_apis/'
};
