import { Injectable } from '@angular/core';
/* Importamos las clases Observable y HttpClient que necesitaremos
para comunicar con las API's y recuperar sus resultados. */
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
/* Importamos los environments, para determinar la URL base de las API's */
import { environment } from '../../../environments/environment';
/* IMportamos al clase Member para poder gestionar objetos
de esta clase en las llamadas y en los Observables */
import { Member } from '../classes/member';

@Injectable()
export class HttpConnectService {
  /* Leemos la URL base de las API's a partir del archivo de configuración.
  La hacemos pública para poder leerla desde el FormComponent para seleccionar
  una imagen que mostrar en el formulario. */
  public URL = environment.APIS_URL;

  /* En el constructor creamos el objeto http de la clase HttpClient,
  que estará disponible en toda la clase del servicio. */
  constructor(private http: HttpClient) { }

  /* El siguiente método lee los registros y obtiene un observable con la matriz de objetos Member. */
  public readRecords$(criterio, orden): Observable<Member[]> {
    return this.http.get<Member[]>(
      this.URL + 'read_records.php?criterio=' + criterio + '&orden=' + orden
    );
  }

  /* El siguiente método llama a la API de borrado pasándole un id.
  El observable vuelve vació, pero debe estar declarado. */
  public deleteRecord$(id: string): Observable<any> {
    return this.http.get(this.URL + 'delete_record.php?id=' + id);
  }

  /* El siguiente método lee los datos de un registro seleccionado para edición. */
  public readCurrentData$(id): Observable<Member> {
    return this.http.get<Member>(this.URL + 'read_record.php?id=' + id);
  }

  /* El siguiente método graba un registro nuevo, o uno editado. */
  public saveRecord$(dataPack: FormData): Observable<any> {
    return this.http.post(this.URL + 'save_record.php', dataPack);
  }

  /* El siguiente método comprueba si un DOI está repetido y, por tanto, no puede usarse. */
  public checkRepeatedDoi$(id, doi): Observable<string> {
    return this.http.post(this.URL + 'check_doi.php', { id, doi }, { responseType: 'text' });
  }
}
