import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a6b-admin-logout',
  templateUrl: './admin-logout.component.html',
  styleUrls: ['./admin-logout.component.css']
})
export class AdminLogoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
