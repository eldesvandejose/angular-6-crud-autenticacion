import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a6b-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  public nombreAdmin = sessionStorage.getItem('nombreAdmin');
  public rolAdmin = sessionStorage.getItem('rolAdmin');

  constructor() { }

  ngOnInit() {
    console.log(this.nombreAdmin);
    console.log(this.rolAdmin);
  }
}
