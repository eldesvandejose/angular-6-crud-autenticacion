import { Component, DoCheck, OnInit } from '@angular/core';
import { CheckAdminService } from './services/check-admin.service';

@Component({
  selector: 'a6b-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, DoCheck {
  public lastEdited: string;

  constructor (private checkAdmin: CheckAdminService) { }

  ngOnInit() { }

  ngDoCheck() {
    this.lastEdited = sessionStorage.getItem('LastEditedName');
  }
}
