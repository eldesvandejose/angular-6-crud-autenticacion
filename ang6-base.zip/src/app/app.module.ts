import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DataPackService } from './services/data-pack.service';
import { GlobalsModule } from './globals/globals.module';
import { MembersModule } from './members/members.module';
import { CheckAdminService } from './services/check-admin.service';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    GlobalsModule,
    MembersModule,
    HttpClientModule
  ],
  providers: [
    DataPackService,
    CheckAdminService
  ],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule { }
