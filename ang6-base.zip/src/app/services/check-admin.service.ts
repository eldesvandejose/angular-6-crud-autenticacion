import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CheckAdminService {
  public token = sessionStorage.getItem('token');
  constructor() {
    if (this.token === null || this.token === undefined || this.token === '') {
      this.emptyData();
    }
  }

  private emptyData() {
    sessionStorage.setItem('nombreAdmin', '');
    sessionStorage.setItem('rolAdmin', '');
  }
}
