import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CheckAdminService {

  private URL = environment.APIS_URL;
  private token: string;
  public nombreAdmin: string;
  public rolAdmin: string;

  constructor(public http: HttpClient) {
    this.token = sessionStorage.getItem('token');
    if (this.token === null || this.token === undefined || this.token === '') {
      this.emptyData();
    } else {
      this.checkToken();
    }
  }

  /**
   * Si no existe el token (el usuario no se ha autenticado, o ha cerrado sesión)
   * se ponen cadenas vacías en las variables que luego se usarán en los componentes para
   * verificar si se trata de un adminitrador autorizado.
   */
  private emptyData() {
    sessionStorage.setItem('nombreAdmin', '');
    sessionStorage.setItem('rolAdmin', '');
  }

  public checkToken() {
    this.checkToken$().subscribe(
      this.checkTokenSuccess.bind(this),
      this.checkTokenError.bind(this)
    );
  }

  public checkToken$(): Observable<any> {
    return this.http.get(this.URL + 'autenticacion/verify_token.php?token=' + localStorage.getItem('token'));
  }

  /**
   * Si hay un token y este es correcto, se ponen los identificadores en
   * las variables de sesión que comprobará cada componente.
   * Si no, se anula el token y se dejan las variables vacías.
   */
  private checkTokenSuccess(result) {
    if (result.correcto === 'S') {
      localStorage.setItem('nombreAdmin', result.nombreAdmin);
      localStorage.setItem('rolAdmin', result.rolAdmin);
    } else {
      localStorage.removeItem('token');
      localStorage.setItem('nombreAdmin', '');
      localStorage.setItem('rolAdmin', '');
    }
  }

  private checkTokenError() {}
}
